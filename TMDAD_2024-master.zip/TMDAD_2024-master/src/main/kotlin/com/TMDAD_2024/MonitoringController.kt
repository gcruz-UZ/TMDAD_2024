package com.TMDAD_2024

import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController

@RestController
@RequestMapping("/api/monitoring")
class MonitoringController {

    // Method to monitor system charge
    @GetMapping("/systemCharge")
    fun getSystemCharge(): ResponseEntity<Double> {
        // Add logic to retrieve system charge
        val systemCharge = 75.0 // Example system charge
        return ResponseEntity(systemCharge, HttpStatus.OK)
    }

    // Method to monitor payload system
    @GetMapping("/payloadSystem")
    fun getPayloadSystem(): ResponseEntity<Double> {
        // Add logic to retrieve payload system
        val payloadSystem = 90.0 // Example payload system
        return ResponseEntity(payloadSystem, HttpStatus.OK)
    }
}
