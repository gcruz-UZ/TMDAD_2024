package com.TMDAD_2024.file

import com.TMDAD_2024.user.User
import org.springframework.data.repository.CrudRepository
import java.util.*

interface FileRepository : CrudRepository<File, Int> {
    // Find files by user
    fun findByUser(user: User): List<File>

    // Find files by group
    fun findByGroupId(groupId: Int): List<File>

    // Save a file
    override fun <S : File?> save(entity: S & Any): S & Any

    // Delete a file by id
    override fun deleteById(id: Int)

}
