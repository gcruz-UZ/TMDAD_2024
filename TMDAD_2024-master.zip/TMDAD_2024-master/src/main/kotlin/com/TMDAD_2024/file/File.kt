package com.TMDAD_2024.file

//package com.TMDAD_2024.user

import com.TMDAD_2024.user.User
import jakarta.persistence.*

@Entity
@Table(name = "file")
data class File (
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    var id: Int,
    var directoryRoute: String,
    var timeStamp: String,
    var id_group: Int,
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id")
    var user: User
)
