package com.TMDAD_2024.file

import com.TMDAD_2024.user.User

import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service

@Service
class FileService(@Autowired private val fileRepository: FileRepository) {

    fun getFileById(id: Int): File? {
        return fileRepository.findById(id).orElse(null)
    }

    fun getFilesByUser(user: User): List<File> {
        return fileRepository.findByUser(user)
    }

    fun saveFile(file: File): File {
        return fileRepository.save(file)
    }

    fun deleteFile(id: Int) {
        fileRepository.deleteById(id)
    }

}
