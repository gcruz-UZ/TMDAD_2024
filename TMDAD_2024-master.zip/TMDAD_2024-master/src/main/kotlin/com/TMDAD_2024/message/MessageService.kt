package com.TMDAD_2024.message

import com.TMDAD_2024.user.User
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service
import java.util.*

@Service
class MessageService(@Autowired private val messageRepository: MessageRepository) {

    fun getMessageById(id: Int): Message? {
        return messageRepository.findById(id).orElse(null)
    }

    fun getMessagesByUser(user: User): List<Message> {
        return messageRepository.findByUser(user)
    }

    fun getMessagesByGroup(groupId: Int): List<Message> {
        return messageRepository.findByGroupId(groupId)
    }

    fun saveMessage(message: Message): Message {
        return messageRepository.save(message)
    }

    fun deleteMessage(id: Int) {
        messageRepository.deleteById(id)
    }

}
