package com.TMDAD_2024.message

// MessageRepository.kt

import com.TMDAD_2024.user.User
import org.springframework.data.jpa.repository.Query
import org.springframework.data.repository.CrudRepository
import java.util.*

interface MessageRepository : CrudRepository<Message, Int> {
    // Find messages by user
    fun findByUser(user: User): List<Message>

    // Find messages by group
    fun findByGroupId(groupId: Int): List<Message>

    // Find messages by user and group
    fun findByUserAndGroupId(user: User, groupId: Int): List<Message>

    // Find messages by timestamp range
    @Query("SELECT m FROM Message m WHERE m.timeStamp BETWEEN :start AND :end")
    fun findByTimestampBetween(start: String, end: String): List<Message>

    // Other query methods?
}
