package com.TMDAD_2024.group

//package com.TMDAD_2024.user

import jakarta.persistence.*

@Entity
@Table(name = "chatroom_permanent")
data class ChatroomPermanent (
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    var id: Int,
    var name: String,
    // Other relevant properties for the permanent chatroom
)
