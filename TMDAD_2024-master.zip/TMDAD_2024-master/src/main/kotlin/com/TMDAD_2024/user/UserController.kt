package com.TMDAD_2024.user

import com.TMDAD_2024.message.MessageRepository
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*

@RestController
@RequestMapping("/api/users")
class UserController(@Autowired private val userRepository: UserRepository,
                     @Autowired private val messageRepository: MessageRepository
){ //

    //get all users
    @GetMapping("")
    fun getAllUsers(): List<User> =
        userRepository.findAll().toList()

    //create user
    @PostMapping("")
    fun createUser(@RequestBody user: User): ResponseEntity<User> {
        val savedUser = userRepository.save(user)
        return ResponseEntity(savedUser, HttpStatus.CREATED)
    }

    //get user by id
    @GetMapping("/{id}")
    fun getUserById(@PathVariable("id") userId: Int): ResponseEntity<User> {
        val user = userRepository.findById(userId).orElse(null)
        return if (user != null) {
            ResponseEntity(user, HttpStatus.OK)
        } else {
            ResponseEntity(HttpStatus.NOT_FOUND)
        }
    }

    //update user
    @PutMapping("/{id}")
    fun updateUserById(@PathVariable("id") userId: Int, @RequestBody user: User): ResponseEntity<User> {
        val existingUser = userRepository.findById(userId).orElse(null)

        if (existingUser == null){
            return ResponseEntity(HttpStatus.NOT_FOUND)
        }

        val updatedUser = existingUser.copy(login = user.login, name = user.name, isSuperuser = user.isSuperuser)
        userRepository.save(updatedUser)
        return ResponseEntity(updatedUser, HttpStatus.OK)
    }

    //delete user
    @DeleteMapping("/{id}")
    fun deletedUSerById(@PathVariable("id") userId: Int): ResponseEntity<User> {
        if (!userRepository.existsById(userId)){
            return ResponseEntity(HttpStatus.NOT_FOUND)
        }

        userRepository.deleteById(userId)
        return ResponseEntity(HttpStatus.NO_CONTENT)
    }

    //
    // Method to send ads along with messages
    @PostMapping("/sendAd/{userId}/{messageId}")
    fun sendAdWithMessage(@PathVariable("userId") userId: Int, @PathVariable("messageId") messageId: Int): ResponseEntity<String> {
        val user = userRepository.findById(userId).orElse(null)
        val message = messageRepository.findById(messageId).orElse(null)

        if (user == null || message == null) {
            return ResponseEntity(HttpStatus.NOT_FOUND)
        }

        // Logic to send ad with message

        return ResponseEntity("Ad sent successfully with message", HttpStatus.OK)
    }

    // Method to assign user to permanent chatroom
    @PostMapping("/{userId}/joinChatroom")
    fun joinPermanentChatroom(@PathVariable("userId") userId: Int, @RequestBody chatroomId: Int): ResponseEntity<String> {
        val user = userRepository.findById(userId).orElse(null)
        if (user == null) {
            return ResponseEntity(HttpStatus.NOT_FOUND)
        }

        // Logic to assign user to permanent chatroom
        // user.joinChatroom(chatroomId)

        return ResponseEntity("User joined permanent chatroom successfully", HttpStatus.OK)
    }

    // Method to analyze messages for trending topics
    @GetMapping("/trendingTopics")
    fun getTrendingTopics(): ResponseEntity<List<String>> {
        // Add logic to analyze messages for trending topics
        val trendingTopics = listOf("Topic1", "Topic2", "Topic3") // Example trending topics
        return ResponseEntity(trendingTopics, HttpStatus.OK)
    }
    //

}

/*

 */