package com.TMDAD_2024

import com.TMDAD_2024.message.MessageRepository
import com.TMDAD_2024.user.User
import com.TMDAD_2024.user.UserRepository
import jakarta.persistence.GeneratedValue
import jakarta.persistence.GenerationType
import jakarta.persistence.Id
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*

@RestController
@RequestMapping("/api/login")
class Controller(@Autowired private val userRepository: UserRepository,
                 @Autowired private val messageRepository: MessageRepository
){ //

    data class Login (
        var username: String,
        var password: String
    )

    //check login for user
    @CrossOrigin(origins = ["http://localhost:3000"])
    @PostMapping("")
    fun login(@RequestBody login: Login): ResponseEntity<User> {
        val user = userRepository.findByLogin(login.username).orElse(null)

        return if (user != null) {
            ResponseEntity(user, HttpStatus.OK)
        } else {
            ResponseEntity(HttpStatus.NOT_FOUND)
        }
    }

    //
    // Method to send ads along with messages
    @PostMapping("/sendAd/{messageId}")
    fun sendAdWithMessage(@PathVariable("messageId") messageId: Int): ResponseEntity<String> {
        val message = messageRepository.findById(messageId).orElse(null)

        if (message == null) {
            return ResponseEntity(HttpStatus.NOT_FOUND)
        }

        // Add logic to send ad with message

        return ResponseEntity("Ad sent successfully with message", HttpStatus.OK)
    }

    // Method to analyze messages for trending topics
    @GetMapping("/trendingTopics")
    fun getTrendingTopics(): ResponseEntity<List<String>> {
        // Add logic to analyze messages for trending topics
        val trendingTopics = listOf("Topic1", "Topic2", "Topic3") // Example trending topics
        return ResponseEntity(trendingTopics, HttpStatus.OK)
    }
    //


}