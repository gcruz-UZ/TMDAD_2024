package com.TMDAD_2024

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class ChatApplicationTests {

	@Test
	fun contextLoads() {
	}

}
