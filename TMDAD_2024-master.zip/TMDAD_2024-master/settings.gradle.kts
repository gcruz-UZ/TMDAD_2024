rootProject.name = "TMDAD_2024"
